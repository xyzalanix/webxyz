# SHBSHB PIXEL

![Image](documentation/specimen/shbshb-specimen.png)

Shbshb Pixel is a slanted serif pixel typeface, based on a very low grid resolution of the CMU Concrete Italic. It was designed during spring 2020 lockdown for Radio Shbshb, a collaborative radio project from Karlsruhe.

Now available on the NoFoundry Map.
Have fun with it!

## About the author

Timothée Charon is a student at HfG Karlsruhe and is part of the „NoFoundry“ which publishes typefaces from students. He is also a founder of Radio Shbshb, for which he developed the Shbshb Pixel Typeface.

## Contact
[Instagram](https://www.instagram.com/kamil30.000/)

## License

This Font Software is licensed under the NoFoundry Eula. This license is enclosed in this repository. For any questions, feel free to contact the [NoFoundry ](abc@nofoundry.xyz).

## Repository Layout

This font repository structure is inspired by [Unified Font Repository v0.3](https://github.com/unified-font-repository/Unified-Font-Repository).

## Publishing

This font is made available through the [NoFoundry](http://nofoundry.xyz/).
